package baritone.utils.accessor;

public interface IBitArray {

    int[] toArray();

    long getMaxEntryValue();

    int getBitsPerEntry();
}
